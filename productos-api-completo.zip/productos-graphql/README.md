# productos-graphql

API GraphQL para gestión de productos construida con Express.js, Apollo Server y Sequelize ORM sobre SQLite.

## Tecnologías

- **Express.js** — framework web
- **Apollo Server** — servidor GraphQL
- **Sequelize ORM** — manejo de base de datos (crea la tabla automáticamente)
- **SQLite** — base de datos local

## Instalación

```bash
npm install
npm start
```

El servidor corre en `http://localhost:4000/graphql`

## Operaciones CRUD

### Leer todos los productos
```graphql
query {
  productos {
    id
    nombre
    descripcion
    precio
  }
}
```

### Leer un producto por ID
```graphql
query {
  producto(id: 1) {
    id
    nombre
    descripcion
    precio
  }
}
```

### Crear producto
```graphql
mutation {
  crearProducto(input: {
    nombre: "Laptop HP"
    descripcion: "Laptop HP 15 pulgadas, 16GB RAM"
    precio: 2500000
  }) {
    id
    nombre
    precio
  }
}
```

### Actualizar producto
```graphql
mutation {
  actualizarProducto(id: 1, input: {
    precio: 2300000
  }) {
    id
    nombre
    precio
  }
}
```

### Eliminar producto
```graphql
mutation {
  eliminarProducto(id: 1)
}
```
