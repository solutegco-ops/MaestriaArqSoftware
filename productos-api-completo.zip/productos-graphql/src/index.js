const express = require('express');
const { ApolloServer } = require('apollo-server-express');
const { typeDefs, resolvers } = require('./schema');
const sequelize = require('./database');
require('./model'); // registra el modelo

const PORT = process.env.PORT || 4000;

async function startServer() {
  const app = express();

  // Apollo Server
  const server = new ApolloServer({
    typeDefs,
    resolvers,
    formatError: (error) => ({
      message: error.message,
      locations: error.locations,
      path: error.path,
    }),
  });

  await server.start();
  server.applyMiddleware({ app, path: '/graphql' });

  // Sincronizar base de datos (ORM crea la tabla si no existe)
  await sequelize.sync({ alter: true });
  console.log('✅ Base de datos sincronizada con Sequelize ORM');

  app.listen(PORT, () => {
    console.log(`🚀 Servidor GraphQL corriendo en http://localhost:${PORT}/graphql`);
    console.log(`📊 GraphQL Playground disponible en http://localhost:${PORT}/graphql`);
  });
}

startServer().catch((error) => {
  console.error('❌ Error al iniciar el servidor:', error);
  process.exit(1);
});
