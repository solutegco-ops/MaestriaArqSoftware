const { DataTypes } = require('sequelize');
const sequelize = require('./database');

const Producto = sequelize.define('Producto', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nombre: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      notEmpty: { msg: 'El nombre no puede estar vacío' },
      len: { args: [1, 255], msg: 'El nombre debe tener entre 1 y 255 caracteres' },
    },
  },
  descripcion: {
    type: DataTypes.TEXT,
    allowNull: false,
    validate: {
      notEmpty: { msg: 'La descripción no puede estar vacía' },
    },
  },
  precio: {
    type: DataTypes.FLOAT,
    allowNull: false,
    validate: {
      isFloat: { msg: 'El precio debe ser un número válido' },
      min: { args: [0], msg: 'El precio no puede ser negativo' },
    },
  },
}, {
  tableName: 'productos',
  timestamps: true,
});

module.exports = Producto;
