const { gql } = require('apollo-server-express');
const Producto = require('./model');

// ── Schema ──────────────────────────────────────────────────────────────────
const typeDefs = gql`
  type Producto {
    id: ID!
    nombre: String!
    descripcion: String!
    precio: Float!
    createdAt: String
    updatedAt: String
  }

  input ProductoInput {
    nombre: String!
    descripcion: String!
    precio: Float!
  }

  input ProductoUpdateInput {
    nombre: String
    descripcion: String
    precio: Float
  }

  type Query {
    productos: [Producto!]!
    producto(id: ID!): Producto
  }

  type Mutation {
    crearProducto(input: ProductoInput!): Producto!
    actualizarProducto(id: ID!, input: ProductoUpdateInput!): Producto!
    eliminarProducto(id: ID!): Boolean!
  }
`;

// ── Resolvers ────────────────────────────────────────────────────────────────
const resolvers = {
  Query: {
    // Leer todos
    productos: async () => {
      try {
        return await Producto.findAll({ order: [['id', 'ASC']] });
      } catch (error) {
        throw new Error(`Error al obtener productos: ${error.message}`);
      }
    },

    // Leer uno por ID
    producto: async (_, { id }) => {
      try {
        const producto = await Producto.findByPk(id);
        if (!producto) {
          throw new Error(`Producto con id ${id} no encontrado`);
        }
        return producto;
      } catch (error) {
        throw new Error(error.message);
      }
    },
  },

  Mutation: {
    // Crear
    crearProducto: async (_, { input }) => {
      try {
        const { nombre, descripcion, precio } = input;
        if (!nombre || !descripcion || precio === undefined) {
          throw new Error('Todos los campos son obligatorios: nombre, descripcion, precio');
        }
        if (precio < 0) {
          throw new Error('El precio no puede ser negativo');
        }
        const producto = await Producto.create({ nombre, descripcion, precio });
        return producto;
      } catch (error) {
        throw new Error(`Error al crear producto: ${error.message}`);
      }
    },

    // Actualizar
    actualizarProducto: async (_, { id, input }) => {
      try {
        const producto = await Producto.findByPk(id);
        if (!producto) {
          throw new Error(`Producto con id ${id} no encontrado`);
        }
        if (input.precio !== undefined && input.precio < 0) {
          throw new Error('El precio no puede ser negativo');
        }
        await producto.update(input);
        return producto;
      } catch (error) {
        throw new Error(`Error al actualizar producto: ${error.message}`);
      }
    },

    // Eliminar
    eliminarProducto: async (_, { id }) => {
      try {
        const producto = await Producto.findByPk(id);
        if (!producto) {
          throw new Error(`Producto con id ${id} no encontrado`);
        }
        await producto.destroy();
        return true;
      } catch (error) {
        throw new Error(`Error al eliminar producto: ${error.message}`);
      }
    },
  },
};

module.exports = { typeDefs, resolvers };
