# productos-grpc

API gRPC para gestión de productos construida con Node.js, @grpc/grpc-js y Sequelize ORM sobre SQLite.

## Tecnologías

- **@grpc/grpc-js** — implementación gRPC para Node.js
- **@grpc/proto-loader** — carga dinámica del archivo .proto
- **Protocol Buffers (.proto)** — contrato del servicio
- **Sequelize ORM** — manejo de base de datos (crea la tabla automáticamente)
- **SQLite** — base de datos local

## Instalación y ejecución

```bash
# Instalar dependencias
npm install

# Iniciar el servidor gRPC (puerto 50051)
npm start

# En otra terminal: ejecutar el cliente de demostración
npm run client
```

## Estructura del servicio (.proto)

```protobuf
service ProductoService {
  rpc ObtenerTodos   (Empty)                     returns (ListaProductos);
  rpc ObtenerPorId   (ProductoId)                returns (Producto);
  rpc Crear          (ProductoInput)             returns (Producto);
  rpc Actualizar     (ActualizarProductoRequest) returns (Producto);
  rpc Eliminar       (ProductoId)                returns (EliminarResponse);
}
```

## Probar con grpcurl (opcional)

```bash
# Instalar grpcurl: https://github.com/fullstorydev/grpcurl

# Listar servicios
grpcurl -plaintext localhost:50051 list

# Obtener todos los productos
grpcurl -plaintext localhost:50051 productos.ProductoService/ObtenerTodos

# Crear producto
grpcurl -plaintext -d '{"nombre":"Monitor LG","descripcion":"Monitor 27 pulgadas 4K","precio":1800000}' \
  localhost:50051 productos.ProductoService/Crear

# Obtener por ID
grpcurl -plaintext -d '{"id":1}' localhost:50051 productos.ProductoService/ObtenerPorId

# Actualizar
grpcurl -plaintext -d '{"id":1,"precio":1600000}' localhost:50051 productos.ProductoService/Actualizar

# Eliminar
grpcurl -plaintext -d '{"id":1}' localhost:50051 productos.ProductoService/Eliminar
```

## Manejo de errores gRPC

| Código gRPC | Situación |
|-------------|-----------|
| `NOT_FOUND` | Producto no existe |
| `INVALID_ARGUMENT` | Datos inválidos (precio negativo, campos vacíos) |
| `INTERNAL` | Error interno del servidor |
