/**
 * Cliente gRPC de demostración
 * Ejecutar con: npm run client
 * (El servidor debe estar corriendo primero: npm start)
 */

const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

const PROTO_PATH = path.join(__dirname, '../proto/producto.proto');
const SERVER_ADDRESS = 'localhost:50051';

const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const productosProto = grpc.loadPackageDefinition(packageDefinition).productos;
const client = new productosProto.ProductoService(
  SERVER_ADDRESS,
  grpc.credentials.createInsecure()
);

// ── Helpers ───────────────────────────────────────────────────────────────────
function log(titulo, data) {
  console.log(`\n${'─'.repeat(50)}`);
  console.log(`📌 ${titulo}`);
  console.log(JSON.stringify(data, null, 2));
}

function handleError(operacion, error) {
  console.error(`\n❌ Error en ${operacion}:`, error.message);
}

// ── Demo secuencial ───────────────────────────────────────────────────────────
async function runDemo() {
  console.log('🔌 Conectando al servidor gRPC en', SERVER_ADDRESS);

  // 1. CREAR
  const nuevoProducto = await new Promise((resolve, reject) => {
    client.Crear(
      { nombre: 'Laptop HP Pavilion', descripcion: 'Laptop 15 pulgadas, 16GB RAM, SSD 512GB', precio: 2500000 },
      (err, res) => (err ? reject(err) : resolve(res))
    );
  }).catch(e => handleError('Crear', e));

  if (nuevoProducto) log('CREAR — Producto creado', nuevoProducto);

  // 2. LEER TODOS
  const todos = await new Promise((resolve, reject) => {
    client.ObtenerTodos({}, (err, res) => (err ? reject(err) : resolve(res)));
  }).catch(e => handleError('ObtenerTodos', e));

  if (todos) log('LEER TODOS — Lista de productos', todos);

  // 3. LEER UNO
  if (nuevoProducto) {
    const uno = await new Promise((resolve, reject) => {
      client.ObtenerPorId({ id: nuevoProducto.id }, (err, res) => (err ? reject(err) : resolve(res)));
    }).catch(e => handleError('ObtenerPorId', e));

    if (uno) log(`LEER UNO — Producto id=${nuevoProducto.id}`, uno);

    // 4. ACTUALIZAR
    const actualizado = await new Promise((resolve, reject) => {
      client.Actualizar(
        { id: nuevoProducto.id, precio: 2200000, descripcion: 'Precio actualizado — oferta especial' },
        (err, res) => (err ? reject(err) : resolve(res))
      );
    }).catch(e => handleError('Actualizar', e));

    if (actualizado) log(`ACTUALIZAR — Producto id=${nuevoProducto.id}`, actualizado);

    // 5. ELIMINAR
    const eliminado = await new Promise((resolve, reject) => {
      client.Eliminar({ id: nuevoProducto.id }, (err, res) => (err ? reject(err) : resolve(res)));
    }).catch(e => handleError('Eliminar', e));

    if (eliminado) log(`ELIMINAR — Producto id=${nuevoProducto.id}`, eliminado);
  }

  console.log('\n✅ Demo completado\n');
  process.exit(0);
}

runDemo();
