const grpc = require('@grpc/grpc-js');
const Producto = require('./model');

// Helper para formatear producto a objeto plano
function formatearProducto(p) {
  return {
    id: p.id,
    nombre: p.nombre,
    descripcion: p.descripcion,
    precio: p.precio,
    createdAt: p.createdAt ? p.createdAt.toISOString() : '',
    updatedAt: p.updatedAt ? p.updatedAt.toISOString() : '',
  };
}

// ── ObtenerTodos ──────────────────────────────────────────────────────────────
async function ObtenerTodos(call, callback) {
  try {
    const productos = await Producto.findAll({ order: [['id', 'ASC']] });
    callback(null, { productos: productos.map(formatearProducto) });
  } catch (error) {
    callback({
      code: grpc.status.INTERNAL,
      message: `Error al obtener productos: ${error.message}`,
    });
  }
}

// ── ObtenerPorId ──────────────────────────────────────────────────────────────
async function ObtenerPorId(call, callback) {
  try {
    const { id } = call.request;
    const producto = await Producto.findByPk(id);
    if (!producto) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: `Producto con id ${id} no encontrado`,
      });
    }
    callback(null, formatearProducto(producto));
  } catch (error) {
    callback({
      code: grpc.status.INTERNAL,
      message: `Error al buscar producto: ${error.message}`,
    });
  }
}

// ── Crear ─────────────────────────────────────────────────────────────────────
async function Crear(call, callback) {
  try {
    const { nombre, descripcion, precio } = call.request;

    if (!nombre || !descripcion) {
      return callback({
        code: grpc.status.INVALID_ARGUMENT,
        message: 'Los campos nombre y descripcion son obligatorios',
      });
    }
    if (precio < 0) {
      return callback({
        code: grpc.status.INVALID_ARGUMENT,
        message: 'El precio no puede ser negativo',
      });
    }

    const producto = await Producto.create({ nombre, descripcion, precio });
    callback(null, formatearProducto(producto));
  } catch (error) {
    callback({
      code: grpc.status.INTERNAL,
      message: `Error al crear producto: ${error.message}`,
    });
  }
}

// ── Actualizar ────────────────────────────────────────────────────────────────
async function Actualizar(call, callback) {
  try {
    const { id, nombre, descripcion, precio } = call.request;

    const producto = await Producto.findByPk(id);
    if (!producto) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: `Producto con id ${id} no encontrado`,
      });
    }

    if (precio < 0) {
      return callback({
        code: grpc.status.INVALID_ARGUMENT,
        message: 'El precio no puede ser negativo',
      });
    }

    const datosActualizados = {};
    if (nombre)      datosActualizados.nombre      = nombre;
    if (descripcion) datosActualizados.descripcion = descripcion;
    if (precio >= 0) datosActualizados.precio      = precio;

    await producto.update(datosActualizados);
    callback(null, formatearProducto(producto));
  } catch (error) {
    callback({
      code: grpc.status.INTERNAL,
      message: `Error al actualizar producto: ${error.message}`,
    });
  }
}

// ── Eliminar ──────────────────────────────────────────────────────────────────
async function Eliminar(call, callback) {
  try {
    const { id } = call.request;
    const producto = await Producto.findByPk(id);
    if (!producto) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: `Producto con id ${id} no encontrado`,
      });
    }
    await producto.destroy();
    callback(null, { exito: true, mensaje: `Producto ${id} eliminado correctamente` });
  } catch (error) {
    callback({
      code: grpc.status.INTERNAL,
      message: `Error al eliminar producto: ${error.message}`,
    });
  }
}

module.exports = { ObtenerTodos, ObtenerPorId, Crear, Actualizar, Eliminar };
