const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');
const sequelize = require('./database');
const handlers = require('./handlers');
require('./model'); // registra el modelo

const PROTO_PATH = path.join(__dirname, '../proto/producto.proto');
const PORT = process.env.PORT || 50051;

// Cargar el archivo .proto
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const productosProto = grpc.loadPackageDefinition(packageDefinition).productos;

async function startServer() {
  // Sincronizar base de datos (Sequelize ORM crea la tabla automáticamente)
  await sequelize.sync({ alter: true });
  console.log('✅ Base de datos sincronizada con Sequelize ORM');

  // Crear servidor gRPC
  const server = new grpc.Server();

  server.addService(productosProto.ProductoService.service, {
    ObtenerTodos: handlers.ObtenerTodos,
    ObtenerPorId: handlers.ObtenerPorId,
    Crear: handlers.Crear,
    Actualizar: handlers.Actualizar,
    Eliminar: handlers.Eliminar,
  });

  server.bindAsync(
    `0.0.0.0:${PORT}`,
    grpc.ServerCredentials.createInsecure(),
    (error, port) => {
      if (error) {
        console.error('❌ Error al iniciar el servidor gRPC:', error);
        process.exit(1);
      }
      console.log(`🚀 Servidor gRPC corriendo en puerto ${port}`);
      console.log(`📡 Escuchando conexiones punto a punto en 0.0.0.0:${port}`);
    }
  );
}

startServer().catch((error) => {
  console.error('❌ Error fatal:', error);
  process.exit(1);
});
