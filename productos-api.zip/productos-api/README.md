# 📦 Productos API REST

Backend de una aplicación web que implementa servicios **API REST** con operaciones **CRUD** completas sobre la entidad `Producto`, usando **Express.js**, **Sequelize ORM** y **SQLite** como base de datos.

---

## 🏗️ Arquitectura del proyecto

```
productos-api/
├── src/
│   ├── app.js                        ← Punto de entrada, configuración Express
│   ├── config/
│   │   └── database.js               ← Conexión Sequelize (ORM)
│   ├── models/
│   │   └── Producto.js               ← Entidad Producto (ORM)
│   ├── controllers/
│   │   └── productoController.js     ← Lógica CRUD
│   ├── routes/
│   │   └── productoRoutes.js         ← Definición de endpoints RESTful
│   └── middlewares/
│       ├── errorHandler.js           ← Manejo centralizado de errores
│       └── validarProducto.js        ← Validaciones con express-validator
├── public/
│   └── index.html                    ← Frontend (consume la API)
├── package.json
└── README.md
```

---

## 🚀 Instalación y ejecución

### Requisitos
- Node.js v18 o superior
- npm

### Pasos

```bash
# 1. Instalar dependencias
npm install

# 2. Iniciar el servidor
npm start

# 3. Abrir en el navegador
# http://localhost:3000
```

El servidor crea automáticamente el archivo `database.sqlite` y la tabla `productos` mediante Sequelize ORM.

---

## 🗄️ Cambiar de base de datos

### PostgreSQL (Supabase / Render)
```js
// src/config/database.js
const sequelize = new Sequelize('postgres://user:password@host:5432/dbname', {
  dialect: 'postgresql',
});
// Instalar: npm install pg pg-hstore
```

### MySQL (Azure / local)
```js
const sequelize = new Sequelize('mydb', 'user', 'password', {
  host: 'localhost',
  dialect: 'mysql',
});
// Instalar: npm install mysql2
```

### MongoDB (con Mongoose)
Requiere reemplazar Sequelize + modelo por Mongoose Schema.

---

## 📋 Entidad Producto

| Campo        | Tipo           | Restricciones                         |
|--------------|----------------|---------------------------------------|
| `id`         | INTEGER        | PK, autoincremento                    |
| `nombre`     | STRING(150)    | Obligatorio, entre 2 y 150 caracteres |
| `descripcion`| TEXT           | Opcional                              |
| `precio`     | DECIMAL(12,2)  | Obligatorio, ≥ 0                      |
| `createdAt`  | DATE           | Automático (Sequelize)                |
| `updatedAt`  | DATE           | Automático (Sequelize)                |

---

## 🔌 Endpoints RESTful

Base URL: `http://localhost:3000/api`

| Método   | Ruta                    | Descripción                          |
|----------|-------------------------|--------------------------------------|
| `GET`    | `/productos`            | Listar todos los productos           |
| `GET`    | `/productos?buscar=txt` | Buscar por nombre                    |
| `GET`    | `/productos/:id`        | Obtener un producto por ID           |
| `POST`   | `/productos`            | Crear un nuevo producto              |
| `PUT`    | `/productos/:id`        | Actualizar completamente             |
| `PATCH`  | `/productos/:id`        | Actualizar parcialmente              |
| `DELETE` | `/productos/:id`        | Eliminar un producto                 |
| `GET`    | `/health`               | Estado del servidor                  |

---

## 📡 Ejemplos de uso (curl)

```bash
# Crear producto
curl -X POST http://localhost:3000/api/productos \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Laptop Dell","descripcion":"Intel i7 16GB","precio":3500000}'

# Listar todos
curl http://localhost:3000/api/productos

# Obtener uno
curl http://localhost:3000/api/productos/1

# Actualizar completo
curl -X PUT http://localhost:3000/api/productos/1 \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Laptop Dell XPS","descripcion":"Actualizado","precio":3800000}'

# Actualizar parcial
curl -X PATCH http://localhost:3000/api/productos/1 \
  -H "Content-Type: application/json" \
  -d '{"precio":3600000}'

# Eliminar
curl -X DELETE http://localhost:3000/api/productos/1
```

---

## 📦 Respuestas JSON estandarizadas

### Éxito — listado
```json
{
  "status": "success",
  "total": 2,
  "pagina": 1,
  "limite": 20,
  "totalPaginas": 1,
  "datos": [ { "id": 1, "nombre": "...", "descripcion": "...", "precio": "..." } ]
}
```

### Éxito — creación
```json
{
  "status": "success",
  "mensaje": "Producto creado exitosamente.",
  "datos": { "id": 1, "nombre": "Laptop Dell", "precio": "3500000.00" }
}
```

### Error — validación
```json
{
  "status": "error",
  "codigo": "VALIDATION_ERROR",
  "mensaje": "Los datos enviados no son válidos.",
  "detalles": ["El nombre es obligatorio.", "El precio debe ser un número mayor o igual a 0."]
}
```

### Error — no encontrado
```json
{
  "status": "error",
  "codigo": "NOT_FOUND",
  "mensaje": "No existe un producto con id 99."
}
```

---

## 🛡️ Buenas prácticas implementadas

- ✅ Separación por capas: rutas → controladores → modelo
- ✅ ORM (Sequelize) para todas las operaciones con BD, sin SQL manual
- ✅ Validación de entradas con `express-validator`
- ✅ Manejo centralizado de errores
- ✅ Respuestas JSON consistentes en todos los endpoints
- ✅ CORS habilitado para peticiones del frontend
- ✅ Logs de peticiones con Morgan
- ✅ Paginación y búsqueda en el listado

---

## 📚 Stack tecnológico

| Tecnología         | Rol                              |
|--------------------|----------------------------------|
| Express.js 4.x     | Framework backend REST           |
| Sequelize 6.x      | ORM (mapeo objeto-relacional)    |
| SQLite             | Base de datos local (sin config) |
| express-validator  | Validación de entradas           |
| Morgan             | Logs HTTP                        |
| CORS               | Cabeceras de seguridad entre orígenes |
