// src/app.js
// Punto de entrada de la aplicación.
// Configura Express, middlewares globales, rutas y sincronización con la BD.

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

const sequelize = require('./config/database');
const productoRoutes = require('./routes/productoRoutes');
const { errorHandler } = require('./middlewares/errorHandler');

// Importar modelo para que Sequelize lo registre antes del sync
require('./models/Producto');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middlewares globales ──────────────────────────────────────────────────────
app.use(cors());                                    // habilita CORS para todos los orígenes
app.use(express.json());                            // parsea bodies JSON
app.use(express.urlencoded({ extended: true }));    // parsea form-data
app.use(morgan('dev'));                             // logs de peticiones en consola

// Servir archivos estáticos del frontend (carpeta /public)
app.use(express.static(path.join(__dirname, '../public')));

// ── Rutas de la API ───────────────────────────────────────────────────────────
app.use('/api/productos', productoRoutes);

// Ruta de salud del servidor
app.get('/api/health', (req, res) => {
  res.json({
    status: 'success',
    mensaje: 'API de Productos funcionando correctamente.',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

// Ruta raíz → sirve el frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Ruta no encontrada (404)
app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    codigo: 'NOT_FOUND',
    mensaje: `La ruta ${req.method} ${req.originalUrl} no existe en esta API.`,
  });
});

// ── Middleware de manejo de errores (debe ir al final) ─────────────────────
app.use(errorHandler);

// ── Sincronizar BD y arrancar servidor ────────────────────────────────────────
sequelize
  .sync({ alter: true })   // alter:true actualiza la tabla si el modelo cambia
  .then(() => {
    console.log('[DB] Base de datos sincronizada con Sequelize ORM.');
    app.listen(PORT, () => {
      console.log(`[SERVER] Servidor corriendo en http://localhost:${PORT}`);
      console.log(`[SERVER] API REST disponible en http://localhost:${PORT}/api/productos`);
    });
  })
  .catch((err) => {
    console.error('[DB] Error al conectar con la base de datos:', err.message);
    process.exit(1);
  });

module.exports = app;
