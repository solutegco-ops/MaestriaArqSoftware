// src/config/database.js
// Configuración de la conexión a la base de datos mediante Sequelize ORM.
// Por defecto usa SQLite (archivo local, sin instalar nada extra).
// Para cambiar a PostgreSQL o MySQL, ajusta dialect y las credenciales.

const { Sequelize } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '../../database.sqlite'),
  logging: (msg) => console.log(`[DB] ${msg}`),
  define: {
    timestamps: true,          // agrega createdAt y updatedAt automáticamente
    underscored: false,
  },
});

module.exports = sequelize;
