// src/controllers/productoController.js
// Controlador con las operaciones CRUD completas para la entidad Producto.
// Cada función maneja errores y devuelve respuestas JSON estandarizadas.

const Producto = require('../models/Producto');
const { crearError } = require('../middlewares/errorHandler');

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/productos
// Lista todos los productos. Soporta búsqueda por nombre (?buscar=texto)
// y paginación (?pagina=1&limite=10).
// ──────────────────────────────────────────────────────────────────────────────
const listarProductos = async (req, res, next) => {
  try {
    const { buscar, pagina = 1, limite = 20 } = req.query;
    const offset = (parseInt(pagina) - 1) * parseInt(limite);

    const where = {};
    if (buscar) {
      const { Op } = require('sequelize');
      where.nombre = { [Op.like]: `%${buscar}%` };
    }

    const { count, rows } = await Producto.findAndCountAll({
      where,
      limit: parseInt(limite),
      offset,
      order: [['createdAt', 'DESC']],
    });

    res.status(200).json({
      status: 'success',
      total: count,
      pagina: parseInt(pagina),
      limite: parseInt(limite),
      totalPaginas: Math.ceil(count / parseInt(limite)),
      datos: rows,
    });
  } catch (err) {
    next(err);
  }
};

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/productos/:id
// Obtiene un producto por su ID.
// ──────────────────────────────────────────────────────────────────────────────
const obtenerProducto = async (req, res, next) => {
  try {
    const { id } = req.params;
    const producto = await Producto.findByPk(id);

    if (!producto) {
      return next(crearError(`No existe un producto con id ${id}.`, 404, 'NOT_FOUND'));
    }

    res.status(200).json({
      status: 'success',
      datos: producto,
    });
  } catch (err) {
    next(err);
  }
};

// ──────────────────────────────────────────────────────────────────────────────
// POST /api/productos
// Crea un nuevo producto. Requiere: nombre, precio. Opcional: descripcion.
// ──────────────────────────────────────────────────────────────────────────────
const crearProducto = async (req, res, next) => {
  try {
    const { nombre, descripcion, precio } = req.body;

    const nuevo = await Producto.create({ nombre, descripcion, precio });

    res.status(201).json({
      status: 'success',
      mensaje: 'Producto creado exitosamente.',
      datos: nuevo,
    });
  } catch (err) {
    next(err);
  }
};

// ──────────────────────────────────────────────────────────────────────────────
// PUT /api/productos/:id
// Reemplaza todos los campos de un producto existente.
// ──────────────────────────────────────────────────────────────────────────────
const actualizarProducto = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion, precio } = req.body;

    const producto = await Producto.findByPk(id);
    if (!producto) {
      return next(crearError(`No existe un producto con id ${id}.`, 404, 'NOT_FOUND'));
    }

    await producto.update({ nombre, descripcion, precio });

    res.status(200).json({
      status: 'success',
      mensaje: 'Producto actualizado exitosamente.',
      datos: producto,
    });
  } catch (err) {
    next(err);
  }
};

// ──────────────────────────────────────────────────────────────────────────────
// PATCH /api/productos/:id
// Actualización parcial: solo modifica los campos enviados en el body.
// ──────────────────────────────────────────────────────────────────────────────
const patchProducto = async (req, res, next) => {
  try {
    const { id } = req.params;
    const campos = {};
    ['nombre', 'descripcion', 'precio'].forEach((campo) => {
      if (req.body[campo] !== undefined) campos[campo] = req.body[campo];
    });

    if (Object.keys(campos).length === 0) {
      return next(crearError('Debe enviar al menos un campo para actualizar.', 400, 'BAD_REQUEST'));
    }

    const producto = await Producto.findByPk(id);
    if (!producto) {
      return next(crearError(`No existe un producto con id ${id}.`, 404, 'NOT_FOUND'));
    }

    await producto.update(campos);

    res.status(200).json({
      status: 'success',
      mensaje: 'Producto actualizado parcialmente.',
      datos: producto,
    });
  } catch (err) {
    next(err);
  }
};

// ──────────────────────────────────────────────────────────────────────────────
// DELETE /api/productos/:id
// Elimina un producto por su ID.
// ──────────────────────────────────────────────────────────────────────────────
const eliminarProducto = async (req, res, next) => {
  try {
    const { id } = req.params;

    const producto = await Producto.findByPk(id);
    if (!producto) {
      return next(crearError(`No existe un producto con id ${id}.`, 404, 'NOT_FOUND'));
    }

    await producto.destroy();

    res.status(200).json({
      status: 'success',
      mensaje: `Producto con id ${id} eliminado correctamente.`,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  listarProductos,
  obtenerProducto,
  crearProducto,
  actualizarProducto,
  patchProducto,
  eliminarProducto,
};
