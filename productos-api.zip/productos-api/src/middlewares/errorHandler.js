// src/middlewares/errorHandler.js
// Middleware centralizado de manejo de errores.
// Captura todos los errores lanzados en controladores y devuelve
// respuestas JSON consistentes con código HTTP apropiado.

const { ValidationError, UniqueConstraintError, DatabaseError } = require('sequelize');

const errorHandler = (err, req, res, next) => {
  console.error(`[ERROR] ${err.message}`);

  // Errores de validación de Sequelize (campos inválidos según el modelo)
  if (err instanceof ValidationError) {
    const messages = err.errors.map((e) => e.message);
    return res.status(422).json({
      status: 'error',
      codigo: 'VALIDATION_ERROR',
      mensaje: 'Los datos enviados no son válidos.',
      detalles: messages,
    });
  }

  // Violación de unicidad
  if (err instanceof UniqueConstraintError) {
    return res.status(409).json({
      status: 'error',
      codigo: 'CONFLICT',
      mensaje: 'Ya existe un registro con ese valor único.',
    });
  }

  // Errores de base de datos
  if (err instanceof DatabaseError) {
    return res.status(500).json({
      status: 'error',
      codigo: 'DATABASE_ERROR',
      mensaje: 'Error interno en la base de datos.',
    });
  }

  // Error genérico con statusCode personalizado
  const statusCode = err.statusCode || 500;
  return res.status(statusCode).json({
    status: 'error',
    codigo: err.code || 'INTERNAL_ERROR',
    mensaje: err.message || 'Error interno del servidor.',
  });
};

// Helper para crear errores HTTP con código
const crearError = (mensaje, statusCode = 500, code = 'INTERNAL_ERROR') => {
  const err = new Error(mensaje);
  err.statusCode = statusCode;
  err.code = code;
  return err;
};

module.exports = { errorHandler, crearError };
