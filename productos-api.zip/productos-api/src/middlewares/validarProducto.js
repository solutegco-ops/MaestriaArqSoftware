// src/middlewares/validarProducto.js
// Reglas de validación para los endpoints de Producto usando express-validator.

const { body, validationResult } = require('express-validator');

// Reglas reutilizables
const reglasProducto = [
  body('nombre')
    .trim()
    .notEmpty().withMessage('El campo "nombre" es obligatorio.')
    .isLength({ min: 2, max: 150 }).withMessage('El nombre debe tener entre 2 y 150 caracteres.'),

  body('descripcion')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('La descripción no puede superar los 1000 caracteres.'),

  body('precio')
    .notEmpty().withMessage('El campo "precio" es obligatorio.')
    .isFloat({ min: 0 }).withMessage('El precio debe ser un número mayor o igual a 0.'),
];

// Reglas para actualización parcial (PATCH): todos los campos son opcionales
const reglasActualizacion = [
  body('nombre')
    .optional()
    .trim()
    .notEmpty().withMessage('El nombre no puede estar vacío.')
    .isLength({ min: 2, max: 150 }).withMessage('El nombre debe tener entre 2 y 150 caracteres.'),

  body('descripcion')
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 1000 }).withMessage('La descripción no puede superar los 1000 caracteres.'),

  body('precio')
    .optional()
    .isFloat({ min: 0 }).withMessage('El precio debe ser un número mayor o igual a 0.'),
];

// Middleware que evalúa el resultado de las validaciones
const manejarErroresValidacion = (req, res, next) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    return res.status(422).json({
      status: 'error',
      codigo: 'VALIDATION_ERROR',
      mensaje: 'Los datos enviados no son válidos.',
      detalles: errores.array().map((e) => e.msg),
    });
  }
  next();
};

module.exports = { reglasProducto, reglasActualizacion, manejarErroresValidacion };
