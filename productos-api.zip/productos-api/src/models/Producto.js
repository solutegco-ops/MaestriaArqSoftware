// src/models/Producto.js
// Entidad Producto definida mediante Sequelize ORM.
// Sequelize se encarga de crear la tabla en la BD automáticamente (sync).

const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database');

class Producto extends Model {}

Producto.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'Identificador único del producto',
    },
    nombre: {
      type: DataTypes.STRING(150),
      allowNull: false,
      validate: {
        notEmpty: { msg: 'El nombre no puede estar vacío' },
        len: { args: [2, 150], msg: 'El nombre debe tener entre 2 y 150 caracteres' },
      },
      comment: 'Nombre del producto',
    },
    descripcion: {
      type: DataTypes.TEXT,
      allowNull: true,
      defaultValue: '',
      comment: 'Descripción breve del producto',
    },
    precio: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      validate: {
        isDecimal: { msg: 'El precio debe ser un número válido' },
        min: { args: [0], msg: 'El precio no puede ser negativo' },
      },
      comment: 'Valor numérico que representa el precio del producto',
    },
  },
  {
    sequelize,
    modelName: 'Producto',
    tableName: 'productos',
  }
);

module.exports = Producto;
