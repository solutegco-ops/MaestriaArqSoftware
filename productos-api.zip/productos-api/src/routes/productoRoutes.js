// src/routes/productoRoutes.js
// Definición de rutas RESTful para la entidad Producto.
// Cada ruta aplica validación antes de llegar al controlador.

const express = require('express');
const router = express.Router();

const {
  listarProductos,
  obtenerProducto,
  crearProducto,
  actualizarProducto,
  patchProducto,
  eliminarProducto,
} = require('../controllers/productoController');

const {
  reglasProducto,
  reglasActualizacion,
  manejarErroresValidacion,
} = require('../middlewares/validarProducto');

// ─── Colección ───────────────────────────────────────────────────────────────
// GET    /api/productos          → listar todos (con paginación y búsqueda)
// POST   /api/productos          → crear nuevo producto
router
  .route('/')
  .get(listarProductos)
  .post(reglasProducto, manejarErroresValidacion, crearProducto);

// ─── Recurso individual ───────────────────────────────────────────────────────
// GET    /api/productos/:id      → obtener uno por ID
// PUT    /api/productos/:id      → reemplazar completamente
// PATCH  /api/productos/:id      → actualizar parcialmente
// DELETE /api/productos/:id      → eliminar
router
  .route('/:id')
  .get(obtenerProducto)
  .put(reglasProducto, manejarErroresValidacion, actualizarProducto)
  .patch(reglasActualizacion, manejarErroresValidacion, patchProducto)
  .delete(eliminarProducto);

module.exports = router;
